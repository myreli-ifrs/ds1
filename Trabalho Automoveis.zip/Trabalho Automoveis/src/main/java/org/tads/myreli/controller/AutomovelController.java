package org.tads.myreli.controller;

import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.ResourceBundle;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.tads.myreli.model.Automovel;
import org.tads.myreli.service.AutomovelJpaService;
import org.tads.myreli.service.AutomovelService;

import javafx.beans.binding.BooleanBinding;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * 
 * @author myreli
 *
 */
public class AutomovelController implements Initializable {

	@FXML
	private TableView<Automovel> tblAuto;
	@FXML
	private TableColumn<Automovel, String> clMarca;
	@FXML
	private TableColumn<Automovel, String> clModelo;
	@FXML
	private TableColumn<Automovel, String> clAno;
	@FXML
	private TableColumn<Automovel, String> clKm;
	@FXML
	private TableColumn<Automovel, String> clPreco;
	@FXML
	private TextField txtMarca;
	@FXML
	private TextField txtModelo;
	@FXML
	private TextField txtAno;
	@FXML
	private TextField txtKm;
	@FXML
	private TextField txtPreco;
	@FXML
	private Button btnSalvar;
	@FXML
	private Button btnAtualizar;
	@FXML
	private Button btnApagar;
	@FXML
	private Button btnLimpart;

	// private AutomovelService service;
	private AutomovelJpaService service;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// service = AutomovelService.getNewInstance();
		EntityManagerFactory fac = Persistence.createEntityManagerFactory("EMFautomovel");
		service = new AutomovelJpaService(fac);
		configuraColunas();
		configuraBindings();
		atualizaDadosTabela();
	}
	
	public void salvar() {
		Automovel c = new Automovel();
		pegaValores(c);
		service.create(c);
		atualizaDadosTabela();
	}

	public void atualizar() throws Exception {
		Automovel c = tblAuto.getSelectionModel().getSelectedItem();
		pegaValores(c);
		service.update(c);
		atualizaDadosTabela();
	}

	public void apagar() throws Exception {
		Automovel c = tblAuto.getSelectionModel().getSelectedItem();
		service.delete(c.getId());
		atualizaDadosTabela();
	}

	public void limpar() {
		tblAuto.getSelectionModel().select(null);
		txtAno.setText("");
		txtKm.setText("");
		txtMarca.setText("");
		txtModelo.setText("");
		txtPreco.setText("");
	}
	
	private void pegaValores(Automovel c) {
		c.setAno(Integer.parseInt(txtAno.getText()));
		c.setKm(Double.parseDouble(txtKm.getText()));
		c.setMarca(txtMarca.getText());
		c.setModelo(txtModelo.getText());
		c.setPreco(Double.parseDouble(txtPreco.getText()));
	}

	private void atualizaDadosTabela() {
		tblAuto.getItems().setAll(service.findAll());
		limpar();
	}

	private void configuraColunas() {
		clAno.setCellValueFactory(new PropertyValueFactory<>("Ano"));
		clKm.setCellValueFactory(new PropertyValueFactory<>("Quilometragem"));
		clMarca.setCellValueFactory(new PropertyValueFactory<>("Marca"));
		clModelo.setCellValueFactory(new PropertyValueFactory<>("Modelo"));
		clPreco.setCellValueFactory(new PropertyValueFactory<>("Preco"));
	}

	private void configuraBindings() {
		BooleanBinding camposPreenchidos = txtMarca.textProperty().isEmpty().or(txtModelo.textProperty().isEmpty());
		BooleanBinding algoSelecionado = tblAuto.getSelectionModel().selectedItemProperty().isNull();
		btnApagar.disableProperty().bind(algoSelecionado);
		btnAtualizar.disableProperty().bind(algoSelecionado);
		btnLimpart.disableProperty().bind(algoSelecionado);
		btnSalvar.disableProperty().bind(algoSelecionado.not().or(camposPreenchidos));
		tblAuto.getSelectionModel().selectedItemProperty().addListener((b, o, n) -> {
			if (n != null) {
				txtAno.setText(String.valueOf(n.getAno()));
				txtKm.setText(String.valueOf(n.getKm()));
				txtMarca.setText(String.valueOf(n.getMarca()));
				txtModelo.setText(String.valueOf(n.getModelo()));
				txtPreco.setText(String.valueOf(n.getPreco()));
			}
		});
	}

}