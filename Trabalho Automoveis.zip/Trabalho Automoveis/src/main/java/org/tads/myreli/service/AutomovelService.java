package org.tads.myreli.service;

import java.util.List;

import org.tads.myreli.model.Automovel;
import org.tads.myreli.service.impl.AutomovelDBService;

/**
 * 
 * @author myreli
 *
 */
public interface AutomovelService {

	public void create(Automovel conta);
	
	public List<Automovel> findAll();

	public Automovel findById(int id);
	
	public void delete(int id);
	
	public void update(Automovel conta);
	
	public static AutomovelService getNewInstance() {
		return new AutomovelDBService();
	}

}