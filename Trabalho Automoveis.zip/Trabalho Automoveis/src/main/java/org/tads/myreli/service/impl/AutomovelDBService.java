package org.tads.myreli.service.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.tads.myreli.model.Automovel;
import org.tads.myreli.service.AutomovelService;

public class AutomovelDBService implements AutomovelService {

	final String DB_USER = "sql10307646";
	final String DB_PASS = "PM5gqgJPqL";
	final String DB_HOST = "jdbc:mysql://sql10.freemysqlhosting.net:3306/sql10307646";

	final String CLASS_DRIVER = "com.mysql.jdbc.Driver";

	final String SQL_INSERT = "INSERT INTO automovel(marca, modelo, ano, quilometragem, preco) VALUES(?, ?, ?, ?, ?)";
	final String SQL_UPDATE = "UPDATE automovel SET marca=?, modelo=?, ano = ?, quilometragem = ?, preco = ? WHERE id = ?";
	final String SQL_GET = "SELECT id, marca, modelo, ano, quilometragem, preco FROM automovel WHERE ID = ?";
	final String SQL_GET_ALL = "SELECT id, marca, modelo, ano, quilometragem, preco FROM automovel";
	final String SQL_DELETE = "DELETE FROM automovel WHERE id = ?";

	@Override
	public void create(Automovel auto) {
		try {
			Connection con = connect();
			PreparedStatement inserted = con.prepareStatement(SQL_INSERT);
			inserted.setString(1, auto.getMarca());
			inserted.setString(2, auto.getModelo());
			inserted.setInt(3, auto.getAno());
			inserted.setDouble(4, auto.getKm());
			inserted.setDouble(5, auto.getKm());
			inserted.executeUpdate();
			inserted.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Error inserting new data");
			System.exit(0);
		} 
	}

	@Override
	public List<Automovel> findAll() {
		List<Automovel> Automovel = new ArrayList<>();
		try {
			Connection con = connect();
			PreparedStatement result = con.prepareStatement(SQL_GET_ALL);
			ResultSet rs = result.executeQuery();
			while (rs.next()) {
				Automovel auto = getAuto(rs);
				Automovel.add(auto);
			}
			result.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Error at find all");
			System.exit(0);
		} 
		return Automovel;
	}

	@Override
	public Automovel findById(int id) {
		Automovel auto = null;
		try {
			Connection con = connect();
			PreparedStatement buscar = con.prepareStatement(SQL_GET);
			buscar.setInt(1, id);
			ResultSet rs = buscar.executeQuery();
			rs.next();
			auto = getAuto(rs);
			buscar.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Error at find by id " + id);
			System.exit(0);
		} 
		return auto;
	}

	@Override
	public void delete(int id) {
		try {
			Connection con = connect();
			PreparedStatement apagar = con.prepareStatement(SQL_DELETE);
			apagar.setInt(1, id);
			apagar.executeUpdate();
			apagar.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Error deleting by id " + id);
			System.exit(0);
		} 
	}

	@Override
	public void update(Automovel auto) {
		try {
			Connection con = connect();
			PreparedStatement inserted = con.prepareStatement(SQL_UPDATE);
			inserted.setString(1, auto.getMarca());
			inserted.setString(2, auto.getModelo());
			inserted.setInt(3, auto.getAno());
			inserted.setDouble(4, auto.getKm());
			inserted.setDouble(5, auto.getKm());
			inserted.setInt(6, auto.getId());
			inserted.executeUpdate();
			inserted.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Error updating id " + auto.getId());
			System.exit(0);
		} 

	}

	private Connection connect() {
		try {
			Class.forName(CLASS_DRIVER);
			return DriverManager.getConnection(DB_HOST, DB_USER, DB_PASS);
		} catch (Exception e) {
			e.printStackTrace();
			if(e instanceof ClassNotFoundException) {
				System.err.println("Check pom for driver instalation");
			} else {
				System.err.println("Check database");
			}
			System.exit(0);
			return null;
		}
	}

	private Automovel getAuto(ResultSet rs) throws SQLException, ParseException {
		Automovel auto = new Automovel();
		auto.setId(rs.getInt(1));
		auto.setMarca(rs.getString(2));
		auto.setModelo(rs.getString(3));
		auto.setAno(rs.getInt(4));
		auto.setKm(rs.getDouble(5));
		auto.setPreco(rs.getDouble(6));
		return auto;
	}

}