/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author robinson.acosta
 */
public class TableTime {
    
    private SimpleStringProperty nome = new SimpleStringProperty("");
    private SimpleStringProperty vitorias = new SimpleStringProperty("");
    private SimpleStringProperty derrotas = new SimpleStringProperty("");
    private SimpleStringProperty pontuacao = new SimpleStringProperty("");
    private SimpleStringProperty golsFavor = new SimpleStringProperty("");
    private SimpleStringProperty golsContra = new SimpleStringProperty("");
    private SimpleStringProperty status = new SimpleStringProperty("Indefinido");
    
    public TableTime() {}
    
    public TableTime(String nome, String vitorias, String derrotas, String golsFavor, String golsContra, String pontuacao) {
        this.nome = new SimpleStringProperty(nome);
        this.vitorias = new SimpleStringProperty(vitorias);
        this.derrotas = new SimpleStringProperty(derrotas);
        this.golsFavor = new SimpleStringProperty(golsFavor);
        this.golsContra = new SimpleStringProperty(golsContra);
        this.pontuacao = new SimpleStringProperty(pontuacao);
    }

    public String getNome() {
        return nome.get();
    }
    
    public String getPontuacao() {
        return pontuacao.get();
    }
    
    public SimpleStringProperty pontuacaoProperty() {
        return golsFavor;
    }

    public void setPontuacao(String pontuacao) {
        this.pontuacao.set(pontuacao);
    }
    
    public SimpleStringProperty nomeProperty() {
        return nome;
    }
    
    public String getGolsFavor() {
        return golsFavor.get();
    }

    public SimpleStringProperty golsFavorProperty() {
        return golsFavor;
    }
    
    public String getGolsContra() {
        return golsContra.get();
    }

    public SimpleStringProperty golsContraProperty() {
        return golsContra;
    }

    public void setNome(String nome) {
        this.nome.set(nome);
    }
 
   
    public void setGolsFavor(String nome) {
        this.golsFavor.set(nome);
    }
    
    public void setGolsContra(String nome) {
        this.golsContra.set(nome);
    }

    public String getVitorias() {
        return vitorias.get();
    }

    public SimpleStringProperty vitoriasProperty() {
        return vitorias;
    }

    public void setVitorias(String vit) {
        this.vitorias.set(vit);
    }
    
    public String getDerrotas() {
        return derrotas.get();
    }

    public SimpleStringProperty DerrotasProperty() {
        return derrotas;
    }

    public void setDerrotas(String der) {
        derrotas.set(der);
    }

    public String getStatus() {
        return status.get();
    }

    public SimpleStringProperty statusProperty() {
        return status;
    }

    public void setStatus(String status) {
        this.status.set(status);
    }
    
    @Override
    public String toString() {
        return this.nome.getValue() + "," + this.vitorias.getValue()+ "," + this.derrotas.getValue() + "," +
                this.golsFavor.getValue() + "," + this.golsContra.getValue() + "," + this.pontuacao.getValue();
    }
}
