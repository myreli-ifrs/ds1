/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import model.TableTime;
import utils.Utils;

/**
 *
 * @author robinson.acosta
 */
public class FXMLDocumentController implements Initializable {

    
    @FXML
    private TextField nJogos;

    @FXML
    private TextField equipe;

    @FXML
    private TextField pontuacao;

    @FXML
    private Button carregar;

    @FXML
    private TextField nVitorias;

    @FXML
    private TextField nDerrotas;

    @FXML
    private TextField nEmpates;

    @FXML
    private TextField gContra;

    @FXML
    private TextField gFavor;

    @FXML
    private TableView<TableTime> status;
    
    @FXML
    private TableColumn<TableTime, String> nome;
    
    @FXML
    private TableColumn<TableTime, String> vitorias;
    
    @FXML
    private TableColumn<TableTime, String> pontuacaoT;
    
    @FXML
    private TableColumn<TableTime, String> derrotas;
    
    @FXML
    private TableColumn<TableTime, String> golsFavor;
    
    @FXML
    private TableColumn<TableTime, String> golsContra;
    
    @FXML
    private TableColumn<TableTime, String> statusDoTime;

    @FXML
    private TextField nTorcedores;

    @FXML
    private Button save;


    @FXML
    private void saveFile(ActionEvent event) throws FileNotFoundException, IOException {
        TableTime time = new TableTime();
        time.setNome(equipe.getText());
        time.setDerrotas(nDerrotas.getText());
        time.setVitorias(nVitorias.getText());
        time.setGolsFavor(gFavor.getText());
        time.setGolsContra(gContra.getText());
        time.setPontuacao(pontuacao.getText());
        File file = new File("times.txt");
        FileReader fileReader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        String response = bufferedReader.readLine();
        if (file.exists()) {
            try(FileWriter fileWriter = new FileWriter(file)){
                fileWriter.write(response + ";" + time.toString());
                fileWriter.close();
                displayInTable(file);
                showAlert("Salvo com sucesso", AlertType.INFORMATION);
            } catch(IOException e){
                showAlert("Ocorreu um erro ao salvar o time", AlertType.ERROR);
            }
        } else {
            showAlert("Ocorreu um erro ao salvar no arquivo", AlertType.ERROR);
        }
    }
    
    private ObservableList<TableTime> listaTimes(String times) {
        
        return FXCollections.observableArrayList(Utils.fillFieldsTime(times));
    }
   
    
    @FXML
    private void loadFromFile(ActionEvent event) {
        try {
            FileChooser fileChooser = new FileChooser();
            File file = fileChooser.showOpenDialog(null);
            if (file != null) {
                if (!file.getName().contains(".txt")) {
                    showAlert("Tipo de arquivo não aceito, tente um .txt", AlertType.ERROR);
                    return;
                };
                
                displayInTable(file);
            };

        } catch (Exception e) {
            System.out.println("Error " + e);
            showAlert("Internal Server Error", AlertType.NONE);
        }
    }
    
    
    void displayInTable(File file) {
        try (FileReader fileReader = new FileReader(file)) {
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String s = bufferedReader.readLine();
            nome.setCellValueFactory(
                    new PropertyValueFactory<>("Nome"));
            vitorias.setCellValueFactory(
                    new PropertyValueFactory<>("Vitorias"));
            derrotas.setCellValueFactory(
                    new PropertyValueFactory<>("Derrotas"));
            golsFavor.setCellValueFactory(
                    new PropertyValueFactory<>("GolsFavor"));
            golsContra.setCellValueFactory(
                    new PropertyValueFactory<>("GolsContra"));
            statusDoTime.setCellValueFactory(
                    new PropertyValueFactory<>("Status"));
            ObservableList<TableTime> times = listaTimes(s);
            TableTime maisVazado = times.get(0);
            TableTime maiorAtaque = times.get(0);
            TableTime maiorNumeroVit = times.get(0);
            for (int i = 0; i < times.size(); i++) {
                if (Integer.parseInt(maisVazado.getGolsContra()) <
                        Integer.parseInt(times.get(i).getGolsContra())) {
                    maisVazado = times.get(i);
                }
                if (Integer.parseInt(maisVazado.getVitorias()) <
                        Integer.parseInt(times.get(i).getVitorias())) {
                    maiorNumeroVit = times.get(i);
                }
                if (Integer.parseInt(maiorAtaque.getGolsFavor()) <
                        Integer.parseInt(times.get(i).getGolsFavor())) {
                    maiorAtaque = times.get(i);
                }
            }
            for(TableTime time: times) {
                setStatus(maisVazado, "Mais vazado", time);
                setStatus(maiorAtaque, "Sofreu menos gols", time);
                setStatus(maiorNumeroVit, "Venceu mais partidas", time);
            }
            status.setItems(times);
        } catch (IOException e) {
            showAlert("Ocorreu um erro na leitura do arquivo", AlertType.ERROR);
        }
    }
    
    void setStatus(TableTime time, String msg, TableTime destiny) {
        if (time.getNome().equals(destiny.getNome())) {
            if (destiny.getStatus().equals("Indefinido"))
                destiny.setStatus(msg);
            else destiny.setStatus(destiny.getStatus() + "|" + msg);
        }
    }

    void showAlert(String message, AlertType type) {
        Alert alert = new Alert(type, message);
        alert.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
