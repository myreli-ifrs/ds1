/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.util.ArrayList;
import java.util.List;
import model.TableTime;

/**
 *
 * @author robinson.acosta
 */
public class Utils {
    
    public static List<TableTime> fillFieldsTime(String times) {
        String[] parsed = times.split(";");
        List<TableTime> parsedTable = new ArrayList<>();
        for (String s : parsed) {
            String[] time = s.split(",");
            TableTime tTime = new TableTime(time[0], time[1], time[2], time[3], time[4], time[5]);
            parsedTable.add(tTime);
        }
        return parsedTable;
    }
 

}
